# Mxpertz Science Fiction - Vite React (Ready source)

This archive contains a ready `src/` folder for a Vite + React project that:
- Fetches stories from the API: https://mxpertztestapi.onrender.com/api/sciencefiction
- Shows cards on the list page and a detail page with 3 tabs
- Handles images from ImageKit path: https://ik.imagekit.io/dev24/{image}

## How to use (quick)
1. Create a new Vite React app:
   ```
   npm create vite@latest my-app -- --template react
   cd my-app
   ```
2. Replace the `src/` folder in the generated project with the `src/` folder from this archive.
3. Install the router dependency:
   ```
   npm install
   npm install react-router-dom
   ```
4. Start the dev server:
   ```
   npm run dev
   ```
5. Open the URL shown by Vite (usually http://localhost:5173)

## How to push to GitHub
1. Create a new repo on GitHub (e.g. `mxpertz-scifi`).
2. Run:
   ```
   git init
   git add .
   git commit -m "Initial: Mxpertz scifi app"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```

## Notes
- This package contains only the `src/` and a README. It intentionally avoids including the generated Vite project files to keep size small.
- If you want, I can generate a full zip with `package.json` and `vite.config` prefilled — tell me and I'll attach it.
