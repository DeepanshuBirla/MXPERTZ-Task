import { useState } from "react";

export default function Tabs({ tabs }){
  const keys = Object.keys(tabs);
  const [active, setActive] = useState(keys[0]);
  return (
    <div className="tabs">
      <div className="tab-list">
        {keys.map(k=> (
          <button key={k} className={`tab-btn ${active===k? 'active':''}`} onClick={()=>setActive(k)}>
            {k}
          </button>
        ))}
      </div>
      <div className="tab-panel">
        {tabs[active]}
      </div>
    </div>
  );
}
