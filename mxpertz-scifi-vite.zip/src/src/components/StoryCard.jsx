import { Link } from "react-router-dom";

function getImageList(raw){
  if(!raw) return [];
  if(Array.isArray(raw)) return raw.filter(Boolean).map(String);
  const str = String(raw);
  return str.split(",").map(s=>s.trim()).filter(Boolean);
}

export default function StoryCard({ story }){
  const id = story?._id || story?.id;
  const title = story?.Title || story?.title || "Untitled";
  const desc = story?.Description || story?.description || story?.content || story?.body || "";
  const images = getImageList(story?.Image || story?.image);
  const cover = images[0];

  return (
    <article className="card">
      <div className="card-img-wrap">
        {cover ? (
          <img
            className="card-img"
            src={`https://ik.imagekit.io/dev24/${cover}`}
            alt={title}
            onError={(e)=>{ e.currentTarget.style.display='none'; }}
          />
        ) : null}
      </div>
      <div className="card-body">
        <h3 className="card-title">{title}</h3>
        <p className="card-desc">{desc ? String(desc).slice(0,120) + (String(desc).length>120?"…":"") : ""}</p>
        <div className="meta">
          {story?.author && <span className="badge">By {story.author}</span>}
          {story?.genre && <span className="badge">{story.genre}</span>}
          {story?.year && <span className="badge">{story.year}</span>}
        </div>
        {id && (
          <Link className="btn" style={{marginTop:12, display:'inline-block'}} to={`/story/${id}`}>Open</Link>
        )}
      </div>
    </article>
  );
}
