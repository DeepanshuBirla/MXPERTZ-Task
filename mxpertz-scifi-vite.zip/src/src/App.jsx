import { Routes, Route, Link, NavLink } from "react-router-dom";
import StoriesList from "./pages/StoriesList";
import StoryDetail from "./pages/StoryDetail";

export default function App() {
  return (
    <div className="app-shell">
      <header className="app-header">
        <Link to="/" className="brand">Mxpertz • Sci‑Fi</Link>
        <nav>
          <NavLink to="/" end>Stories</NavLink>
        </nav>
      </header>

      <main className="app-main">
        <Routes>
          <Route path="/" element={<StoriesList />} />
          <Route path="/story/:id" element={<StoryDetail />} />
        </Routes>
      </main>

      <footer className="app-footer">© {new Date().getFullYear()} • Demo build</footer>
    </div>
  );
}
