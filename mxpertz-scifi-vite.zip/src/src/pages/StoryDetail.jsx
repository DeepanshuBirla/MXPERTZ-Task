import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import Tabs from "../components/Tabs";
import Loader from "../components/Loader";

function getImageList(raw){
  if(!raw) return [];
  if(Array.isArray(raw)) return raw.filter(Boolean).map(String);
  const str = String(raw);
  return str.split(",").map(s=>s.trim()).filter(Boolean);
}

export default function StoryDetail(){
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(()=>{
    (async ()=>{
      try{
        const res = await fetch(`https://mxpertztestapi.onrender.com/api/sciencefiction/${id}`);
        if(!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();
        setData(json);
      }catch(err){
        setError(String(err.message||err));
      }finally{
        setLoading(false);
      }
    })();
  },[id]);

  const images = useMemo(()=> getImageList(data?.Image || data?.image), [data]);
  const title  = data?.Title || data?.title || "Untitled";
  const desc   = data?.Description || data?.description || data?.content || data?.body || "";

  if(loading) return <Loader label="Loading story…"/>;
  if(error) return <p style={{color:'#fca5a5'}}>Error: {error}</p>;
  if(!data) return <p>Not found.</p>;

  const overview = (
    <div className="detail-hero">
      {images[0] && (
        <img className="hero-img" src={`https://ik.imagekit.io/dev24/${images[0]}`} alt={title}
             onError={(e)=>{ e.currentTarget.style.display='none'; }} />
      )}
      <div>
        <h1 className="h1">{title}</h1>
        {data?.author && <p className="muted">By {data.author}</p>}
        <p style={{marginTop:10}}>{String(desc)}</p>
        <div className="meta" style={{marginTop:14}}>
          {data?.genre && <span className="badge">{data.genre}</span>}
          {data?.year && <span className="badge">{data.year}</span>}
          {data?._id && <span className="badge">ID: {data._id}</span>}
        </div>
      </div>
    </div>
  );

  const gallery = (
    <div className="detail-gallery">
      {images.length ? images.map((img, i)=> (
        <img key={i} className="hero-img" style={{aspectRatio:'1/1'}}
             src={`https://ik.imagekit.io/dev24/${img}`} alt={`${title} ${i+1}`}
             onError={(e)=>{ e.currentTarget.style.display='none'; }} />
      )) : <p className="muted">No images available.</p>}
    </div>
  );

  const metaRows = Object.entries(data || {})
    .filter(([k]) => !["Image","image","Description","description","content","body","Title","title"].includes(k))
    .map(([k,v])=> (
      <tr key={k}><th>{k}</th><td>{Array.isArray(v)? v.join(", ") : String(v)}</td></tr>
    ));

  const meta = (
    <div style={{overflowX:'auto'}}>
      <table className="table">
        <thead><tr><th>Field</th><th>Value</th></tr></thead>
        <tbody>{metaRows}</tbody>
      </table>
    </div>
  );

  return (
    <div>
      <Link className="btn" to="/">← Back</Link>

      <Tabs tabs={{
        Overview: overview,
        Images: gallery,
        Meta: meta
      }} />
    </div>
  );
}
