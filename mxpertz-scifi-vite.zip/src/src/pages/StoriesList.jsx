import { useEffect, useMemo, useState } from "react";
import StoryCard from "../components/StoryCard";
import Loader from "../components/Loader";

export default function StoriesList(){
  const [all, setAll] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState("");
  const [visible, setVisible] = useState(24);

  useEffect(()=>{
    (async ()=>{
      try{
        const res = await fetch("https://mxpertztestapi.onrender.com/api/sciencefiction");
        if(!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        setAll(Array.isArray(data) ? data : (Array.isArray(data?.data)? data.data : []));
      }catch(err){
        setError(String(err.message||err));
      }finally{
        setLoading(false);
      }
    })();
  },[]);

  const filtered = useMemo(()=>{
    const q = query.trim().toLowerCase();
    if(!q) return all;
    return all.filter(s=>{
      const title = (s?.Title || s?.title || "").toLowerCase();
      const desc  = (s?.Description || s?.description || s?.content || s?.body || "").toLowerCase();
      return title.includes(q) || desc.includes(q);
    });
  },[all, query]);

  const list = filtered.slice(0, visible);

  if(loading) return <Loader label="Fetching stories…"/>;
  if(error) return <p style={{color:'#fca5a5'}}>Error: {error}</p>;
  if(!filtered.length) return (
    <div>
      <div className="toolbar">
        <input className="input" placeholder="Search stories…" value={query} onChange={e=>setQuery(e.target.value)} />
      </div>
      <p>No stories found.</p>
    </div>
  );

  return (
    <div>
      <div className="toolbar">
        <input className="input" placeholder="Search stories…" value={query} onChange={e=>setQuery(e.target.value)} />
        <span className="muted">Total: {filtered.length}</span>
      </div>

      <section className="grid">
        {list.map((s)=> (
          <StoryCard key={s?._id || s?.id || crypto.randomUUID()} story={s} />
        ))}
      </section>

      {visible < filtered.length && (
        <button className="btn loadmore" onClick={()=>setVisible(v=>v+24)}>Load more</button>
      )}
    </div>
  );
}
